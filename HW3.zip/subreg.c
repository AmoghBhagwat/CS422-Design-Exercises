#include <stdio.h>

int main(int argc, char** argv) {
   char a[50];
   int i,j;
   j = 0x12345678;
   
   memcpy(a+17,&j,sizeof(int));
   
   for (i = 17; i <= 20; i++) {
      printf("%#x ", a[i]);
   }
   
   printf("\n");
   return 0;
}
